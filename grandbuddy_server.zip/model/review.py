from sqlalchemy import String, DECIMAL, Text, DateTime, ForeignKeyConstraint
from sqlalchemy.orm import Mapped, mapped_column
from datetime import datetime, timezone
from model.base_class import Base
import uuid

class Review(Base):
    __tablename__ = "review"
    
    review_uuid: Mapped[str] = mapped_column(
        String(36), primary_key = True, default = lambda: str(uuid.uuid4())
    )
    request_uuid: Mapped[str] = mapped_column(
        String(36)
    )
    user_uuid: Mapped[str] = mapped_column(
        String(36)
    )
    rating: Mapped[float] = mapped_column(
        DECIMAL, nullable = False
    )
    content: Mapped[str] = mapped_column(
        Text, nullable = True
    )
    created: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=lambda: datetime.now(timezone.utc)
    )
    
    __table_args__ = (
        ForeignKeyConstraint(
            ["request_uuid"],
            ["request.request_uuid"]
        ),
        ForeignKeyConstraint(
            ["user_uuid"],
            ["user.user_uuid"]
        )
    )
    